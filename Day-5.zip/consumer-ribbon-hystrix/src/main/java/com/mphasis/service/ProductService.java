package com.mphasis.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.mphasis.domain.Product;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@Service("productService")
@Scope("singleton")
public class ProductService {

	@Autowired
	private RestTemplate restTemplate;

	@HystrixCommand(fallbackMethod = "fallbackMethodForGetProductById")
	public Product getProductById(Long id) {

		Product product = restTemplate.getForObject(
				"http://product-service/products/" + id, Product.class);

		return product;
	}
	
	public Product fallbackMethodForGetProductById(Long id) {
		
		return new Product(id, "Dell", 23333.0);
	}
}
