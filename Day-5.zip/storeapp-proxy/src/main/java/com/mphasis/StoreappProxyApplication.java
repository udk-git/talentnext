package com.mphasis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.zuul.EnableZuulProxy;
import org.springframework.context.annotation.Bean;

import com.mphasis.filter.ErrorFilter;
import com.mphasis.filter.PostFilter;
import com.mphasis.filter.PreFilter;
import com.mphasis.filter.RouteFilter;

@EnableZuulProxy
@SpringBootApplication
public class StoreappProxyApplication {

	public static void main(String[] args) {
		SpringApplication.run(StoreappProxyApplication.class, args);
	}

	@Bean
	public PreFilter getPreFilter() {
		
		return new PreFilter();
	}

	@Bean
	public PostFilter getPostFilter() {
		
		return new PostFilter();
	}

	@Bean
	public ErrorFilter getErrorFilter() {
		
		return new ErrorFilter();
	}

	@Bean
	public RouteFilter getRouteFilter() {
		
		return new RouteFilter();
	}
}
