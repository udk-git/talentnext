package com.mphasis.service;

import java.util.List;

import com.mphasis.domain.Product;

public interface IProductService {

	Product addProduct(Product product);
	
	Product updateProduct(Product product);
	
	void deleteProductById(Long id);
	
	Product getProductById(Long id);
	
	List<Product> getAllProducts();
}
