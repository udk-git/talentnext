package com.mphasis.fallback;

import java.util.Arrays;
import java.util.List;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.mphasis.domain.Product;
import com.mphasis.proxy.ProductServiceProxy;

@Service
@Scope("singleton")
public class ProductServiceFallback implements ProductServiceProxy {

	@Override
	public List<Product> getAllProducts() {
		return Arrays.asList(new Product());
	}

	@Override
	public Product getProductById(Long id) {
		return new Product(id, "Dell", 23232.0);
	}

}
