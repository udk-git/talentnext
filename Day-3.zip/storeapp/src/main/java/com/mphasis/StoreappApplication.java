package com.mphasis;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

import com.mphasis.domain.Product;
import com.mphasis.repository.ProductRepository;

@EnableEurekaClient
@SpringBootApplication
public class StoreappApplication implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(StoreappApplication.class, args);
	}

	@Autowired
	@Qualifier(value = "productRepository")
	private ProductRepository productRepository;
	
	@Override
	public void run(String... args) throws Exception {
		
		productRepository.save(new Product(null, "LG", 53223.0));
		productRepository.save(new Product(null, "Samsung", 33223.0));
		productRepository.save(new Product(null, "Dell", 43223.0));
		productRepository.save(new Product(null, "Philips", 32223.0));
		productRepository.save(new Product(null, "Apple", 73223.0));
	}

}
