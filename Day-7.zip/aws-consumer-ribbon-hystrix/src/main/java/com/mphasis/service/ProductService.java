package com.mphasis.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.mphasis.domain.Product;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@Service("productService")
@Scope("singleton")
public class ProductService {

	@Value("${PRODUCT_SERVICE_URI:http://localhost:8080}")
	private String productServiceHost;

	@HystrixCommand(fallbackMethod = "fallbackMethodProductById")
	public Product getProductById(long id) {

		RestTemplate restTemplate = new  RestTemplate();
		Product product = restTemplate.getForObject(
				productServiceHost + "/api/storeapp-microservice/products/" + id, Product.class);

		return product;
	}

	public Product fallbackMethodProductById(long id) {
		return new Product(id, "Dell", 23232.0);
	}
}


